<html><head/><body>
<script type="text/javascript">
who = {
    "name": 'Chuck',
    "age": 29, 
    "college": true,
    "offices" : [ '3350DMC', '3437NQ' ],
    "skills" : { "fortran": 10, "C": 10, 
        "C++": 5, "python" : 7 }
};
window.console && console.log(who);
</script>
<p>Check out the console.log to see the cool object</p>
<pre>
who = {
    "name": 'Chuck',
    "age": 29, 
    "college": true,
    "offices" : [ '3350DMC', '3437NQ' ],
    "skills" : { "fortran": 10, "C": 10, 
        "C++": 5, "python" : 7 }
};
</pre>
</body>
